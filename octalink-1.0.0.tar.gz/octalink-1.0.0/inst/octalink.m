## -*- texinfo -*-
## @deftypefn  {} {} octalink ()
## @deftypefnx {} {} octalink (@var{model_json_path})
## Launch the OctaLink visual block diagram modeling environment.
## @end deftypefn

function octalink (model_path = "")
  pkg_dir = fileparts (mfilename ("fullpath"));
  gui_script = fullfile (pkg_dir, "octalink_gui.py");

  if (! exist (gui_script, "file"))
    error ("octalink: could not locate octalink_gui.py in %s", pkg_dir);
  endif

  printf ("Launching OctaLink Visual Modeling Environment...\n");
  __octalink__ (gui_script, model_path);
endfunction
